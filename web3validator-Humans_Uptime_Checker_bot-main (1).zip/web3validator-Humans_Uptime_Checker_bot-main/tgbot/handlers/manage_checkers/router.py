from aiogram import Router


checker_router = Router()
